<?php
/* 

Plugin Name: publitickets 

Plugin URI: https://publitickets.com/ 

Description: publitickets.

Version: 1.0 

Author: Ivan Ramos

Author URI: zowarin@gmail.com

License: GPLv2 or later 

Text Domain: publitickets 

*/
defined( 'ABSPATH' ) || exit;
if ( ! defined( 'PT_PLUGIN_FILE' ) ) {
	define( 'PT_PLUGIN_FILE', __FILE__ );
}
if ( ! defined( 'PT_PLUGIN_PATH' ) ) {
	define( 'PT_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

// *************************************************** //

if(! class_exists('WPPubliticket_Plugin')) {
    include_once dirname( PT_PLUGIN_FILE ) . '/includes/WPPubliticket_Plugin.php';
}

if(!class_exists('WPPubliticket_Api')) {
	include_once dirname( PT_PLUGIN_FILE ) . '/includes/WPPubliticketPubliticket_Api.php';
}

if(!class_exists('WPPubliticket_Ticket')) {
	include_once dirname( PT_PLUGIN_FILE ) . '/includes/WPPubliticket_Ticket.php';
}

// *************************************************** //
function PT() { 
	return WPPubliticket_Plugin::instance();
}

function PTAPI() {
	return WPPubliticket_Api::instance();
}

function PTTICKET() {
	return WPPubliticket_Ticket::instance();
}
// *************************************************** //
$GLOBALS['publiticket'] = PT();
$GLOBALS['publiticket_api'] = PTAPI();
$GLOBALS['pb_ticket'] = PTTICKET();
// *************************************************** //