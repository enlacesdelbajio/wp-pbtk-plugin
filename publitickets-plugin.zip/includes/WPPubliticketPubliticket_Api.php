<?php
defined( 'ABSPATH' ) || exit;


final class WPPubliticket_AdminPage {
	protected static ?WPPubliticket_AdminPage $_instance = null;
	public static function instance(): ?WPPubliticket_AdminPage
	{
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    const ID = 'pd-admin-forms';
    const domain = 'publitickets';

	public function init(): void {
		add_action('admin_menu', array($this, 'add_menu_page'), 20);
		add_action('admin_init', array($this, 'add_custom_setting'));
    }
	public function get_id(): string {
		return self::ID;
	}

    public function get_header_section() : string {
        return self::ID.'_header_section';
    }
	public function get_section_name() : string {
		return self::ID.'_section_name';
	}
	public function get_setting_sections() : string {
		return self::ID.'_theme_options';
	}
	public function add_menu_page(): void {
		add_menu_page(
			esc_html__('Publitickets Configuration', self::domain),
			esc_html__('Publitickets Configuration', self::domain),
			'manage_options',
			$this->get_id(),
			array(&$this, 'theme_options_page'),
			''
		);
    }
    public function add_custom_setting(): void {
	    register_setting( $this->get_header_section(), 'client_id' );
	    register_setting( $this->get_header_section(), 'api_key' );
	    register_setting( $this->get_header_section(), 'api_host' );
	    register_setting( $this->get_header_section(), 'api_base' );

	    add_settings_section( $this->get_section_name(), 'Client Config',  array(&$this, 'get_section' ), $this->get_setting_sections());
	    add_settings_field( 'client_id', 'Client Id', array(&$this, 'get_input' ), $this->get_setting_sections(), $this->get_section_name() , array('name' => 'client_id' , 'placeholder' => 'Client Id') );
	    add_settings_field( 'api_key', 'Api Key',  array(&$this, 'get_input' ), $this->get_setting_sections(), $this->get_section_name(), array('name' => 'api_key' , 'placeholder' => 'Api Key') );
	    add_settings_field( 'api_host', 'Api Search',  array(&$this, 'get_input' ), $this->get_setting_sections(), $this->get_section_name(), array('name' => 'api_host' , 'placeholder' => 'Search') );
	    add_settings_field( 'api_base', 'Shopping Cart',  array(&$this, 'get_input' ), $this->get_setting_sections(), $this->get_section_name(), array('name' => 'api_base' , 'placeholder' => 'Shopping Cart') );
    }
    public function theme_options_page(): void {
        ?>
        <div class="wrap">
            <h1>Publitickets</h1>
	        <?php settings_errors(); ?>
            <form method="post" action="options.php">
                <?php
                    settings_fields($this->get_header_section());
                    do_settings_sections($this->get_setting_sections());
                    submit_button();
                ?>
            </form>
        </div>
        <?php
    }
	public function get_section(): void {
        echo '';
    }
    public function get_input(array $args): void {
	    $value = esc_attr( get_option( $args['name'] ) );
	    echo '<textarea class="large-text code" name="'.$args['name'].'">'.$value.'</textarea>';
    }
    public function getConfig(): WPPubliticket_ApiConfig {
        return new WPPubliticket_ApiConfig(
	        esc_attr(get_option('client_id' , '')),
	        esc_attr(get_option('api_key', '')),
	        esc_attr(get_option('api_host', ''))
        );
    }
}

final class WPPubliticket_ApiConfig {
    private string $clientId;
    private string $apiKey;
	private string $host;
	private string $api_token;

	public function __construct($clientId = '', $apiKey = '', $host = '')
    {
	    $this->clientId = $clientId;
	    $this->apiKey = $apiKey;
	    $this->host = $host;
	    //------------------------------------
	    //------------------------------------
	    //------------------------------------
	    $this->api_token = '/auth/token'; // solo vamos a usar el plugin para administrar la seguridaed
    }

    public function getTokenConfig(): array
    {
        return array(
            'clientId' => $this->clientId ,
            'apiKey' => $this->apiKey
        );
    }
    public function  get_call_api_token(): string {
	    return  $this->host . $this->api_token;
    }

}
final class WPPubliticket_Api {
    protected static ?WPPubliticket_Api $_instance = null;
    protected WPPubliticket_ApiConfig $config;

    public static function instance(): ?WPPubliticket_Api
    {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self(WPPubliticket_AdminPage::instance()->getConfig());
        }
        return self::$_instance;
    }

    public function __construct(WPPubliticket_ApiConfig $config) {
        $this->config = $config;
    }

	/**
	 * @throws ServerException
	 */
	public function call_token(){
        return $this->call_api_token($this->config->getTokenConfig());
    }


    /**
     * @throws ServerException
     */
    private function call_api_token($params=array()) {
        $request = $this->config->get_call_api_token();
        $curl = curl_init($request);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl, CURLOPT_POSTFIELDS,json_encode($params));
        $get_data = curl_exec($curl);
        if (!curl_errno($curl)) {
            switch ($http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE)) {
                case 200:  # OK
                    curl_close($curl);
                    return json_decode($get_data, true);
                default:
                    $log_file = 'pt_404_errors.log';
                    $message = date("Y-m-d H:i:s") . " - " . $_SERVER['REQUEST_URI'] . "\n";
                    error_log($message, 3, $log_file);
                    curl_close($curl);
                    throw new ServerException('Error call Api Service | call_api_token ' ,$http_code);
            }
        }
        curl_close($curl);
	    throw new ServerException('Error call Api Service | call_api_token ' ,404);
    }
}

class ServerException extends Exception {
    public function __construct($msg, $val = 0, Exception $old = null) {
        parent::__construct($msg, $val, $old);
    }
}

