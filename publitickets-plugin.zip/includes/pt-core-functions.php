<?php
/**
 * UTILS
 */
function pt_plugin_path(): string {
	return untrailingslashit( plugin_dir_path( PT_PLUGIN_FILE ) );
}

function pt_get_template_file( $name, $template = '' ): string {
	$file = get_stylesheet_directory() . '/publitickets/' . $name . '.php';
	if ( @file_exists( $file ) ) {
		return $file;
	}

	$file = pt_plugin_path() . '/templates/' . $name . '.php';
	if ( @file_exists( $file ) ) {
		return $file;
	}

	return $template;
}


