<?php
defined( 'ABSPATH' ) || exit;

if(!class_exists('WPPubliticket_Ticket')) {
	include_once dirname( PT_PLUGIN_FILE ) . '/includes/WPPubliticket_Ticket.php';
}


final class WPPubliticket_Plugin {
    protected static ?WPPubliticket_Plugin $_instance = null;
    private ?WPPubliticket_Ticket $ticket;
	private ?WPPubliticket_AdminPage $admin;

	public static function instance(): ?WPPubliticket_Plugin
    {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct() {
	    // --------------------------------
	    $this->includes();
        // --------------------------------
        $this->ticket =  WPPubliticket_Ticket::instance();
        // --------------------------------
        register_activation_hook( __FILE__, array( $this, 'plugin_prefix_activate') ); // activacion del plugin
        register_deactivation_hook( __FILE__, array( $this, 'remove_custom_type_post' ) ); // desactivacion del plugin
        add_action( 'init', array( $this, 'add_custom_type_post' ) ); // inializa el tipo de post
        // add_filter( "pre_handle_404", array( $this, 'modify_pre_handle_404_defaults' ), 10, 2 ); // manejo de slug
        // add_filter( 'template_include', array( $this ,'template_loader') ); // carga de template
        // -----------------------------------
        // -----------------------------------
        // ----------------------------------
        add_shortcode('publiticket_events', 'cp_list_events'); // listado de eventos
        add_shortcode('publiticket_events_details', 'cp_events_details'); // detalle de eventos
        add_shortcode('publiticket_search_events', 'cp_search_events'); // buscador de eventos
	    add_shortcode('publiticket_carousel', 'cp_events_carousel');// carrusel
	    add_shortcode('publiticket_category', 'cp_events_categoy');// category
        add_action('wp_enqueue_scripts', function() {
            // carga de componentes vue
	        wp_register_script('pt_components',
		        plugins_url( '/js/components/comp.js' , __FILE__ ),
		        array (),
		        '1.0', true);
            // carga de estilos de componentes vue
	        wp_register_style('pt_components_css' ,
		        plugins_url('/js/components/comp.css', __FILE__ )
	        );
        });
	    // --------------------------------
	    // --------------------------------
	    // --------------------------------
	    $this->admin =  WPPubliticket_AdminPage::instance(); // pagina de administración
	    $this->admin?->init(); // inicializa pagian de administración
        // -----------------------------------
        // -----------------------------------
        // -----------------------------------
	    add_action('rest_api_init' , function () {
            add_action( 'rest_pre_serve_request', function () {
                header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Wpml-Language', true );
                header("Access-Control-Allow-Origin: *"); // todo sacar la url de sitio para filtrar el CORS
            } );
            // -----------------------------------
            // -----------------------------------
            // -----------------------------------
            // -----------------------------------
            register_rest_route('publiticket/v1', '/search/show/top', array(
                'methods'  => 'GET',
                'callback' => function() {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root. '/search/show/top';
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_get(
                        $apiUrl,
                        array(
                            'sslverify' => FALSE,
                            'headers'     => array(
                                'Authorization' => 'Bearer ' .$token['accessToken'],
                            ),
                        )
                    );
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return null;
                    }
                }
            ));
		    // -----------------------------------
            register_rest_route('publiticket/v1', '/search/show/slider', array(
                'methods'  => 'GET',
                'callback' => function() {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root. '/search/show/slider';
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_get(
                        $apiUrl,
                        array(
                            'sslverify' => FALSE,
                            'headers'     => array(
                                'Authorization' => 'Bearer ' .$token['accessToken'],
                            ),
                        )
                    );
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return null;
                    }
                }
            ));
            // http://pb.multisite/t1/wp-json/publiticket/v1/search?query=t&pageSize=4&page=1
            register_rest_route('publiticket/v1','search', array(
                'methods'  => 'GET',
                'args' => array(
                    'query' => array(
                        'type' => 'string',
                        'required'  => true,
                    ),
                    'pageSize' => array(
                        'required'  => true,
                    ),
                    'page' => array(
                        'required' => true,
                    ),
                ),
                'callback' => function( $data ) {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root .'/search?query='.$data->get_param( 'query' ).'&pageSize='.$data->get_param( 'pageSize' ).'&page='.$data->get_param( 'page' );
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_get(
                        $apiUrl,
                        array(
                            'sslverify' => FALSE,
                            'headers'     => array(
                                'Authorization' => 'Bearer ' .$token['accessToken'],
                            ),
                        )
                    );
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        header('pagination: '. wp_remote_retrieve_header($response, 'pagination'));
                        header('Access-Control-Expose-Headers: pagination,errors-paginate-filter');
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return null;
                    }
                }
            ));
            // http://pb.multisite/t1/wp-json/publiticket/v1/calendar/teatro-auditorio-nacional
            register_rest_route('publiticket/v1' ,'calendar/(?P<slug>[a-zA-Z0-9-]+)' , array(
                'methods'  => 'GET',
                'args' => array(
                    'slug' => array(
                        'required' => true
                    )
                ),
                'callback' => function( $data ) {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root .'/calendar/'. $data->get_param( 'slug' );
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_get(
                        $apiUrl,
                        array(
                            'sslverify' => FALSE,
                            'headers'     => array(
                                'Authorization' => 'Bearer ' .$token['accessToken'],
                            ),
                        )
                    );
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return 'fail';
                    }
                }
            ));
            // http://pb.multisite/t1/wp-json/publiticket/v1/calendar?pageSize=5&page=1
            register_rest_route('publiticket/v1' ,'calendar' , array(
                'methods'  => 'POST',
                'args' => array(
                    'pageSize' => array(
                        'required'  => true,
                    ),
                    'page' => array(
                        'required' => true,
                    ),
                ),
                'callback' => function( $data) {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root .'/calendar?pageSize='.$data->get_param( 'pageSize' ).'&page='.$data->get_param( 'page' );
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_post($apiUrl, array(
                        'sslverify' => FALSE,
                        'headers'     => array(
                            'Content-Type' => 'application/json; charset=utf-8',
                            'Authorization' => 'Bearer ' .$token['accessToken'],
                        ),
                        'body' => json_encode($data->get_params()),
                        'data_format' => 'body',
                    ));
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        header('pagination: '. wp_remote_retrieve_header($response, 'pagination'));
                        header('Access-Control-Expose-Headers: pagination,errors-paginate-filter');
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return 'fail';
                    }
                }
            ));
            // http://pb.multisite/t1/wp-json/publiticket/v1/calendar/show/40
            register_rest_route('publiticket/v1', '/calendar/show/(?P<id>\d+)', array(
                'methods'  => 'GET',
                'args' => array(
                    'id' => array(
                        'required' => true
                    )
                ),
                'callback' => function( $data ) {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root. '/calendar/show/'.$data->get_param( 'id' );
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_get(
                        $apiUrl,
                        array(
                            'sslverify' => FALSE,
                            'headers'     => array(
                                'Authorization' => 'Bearer ' .$token['accessToken'],
                            ),
                        )
                    );
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return null;
                    }
                }
            ));
            // http://pb.multisite/t1/wp-json/publiticket/v1/calendar/year/2024/month/12
            register_rest_route('publiticket/v1' ,'calendar/year/(?P<year>\d+)/month/(?P<month>\d+)' , array(
                'methods'  => 'POST',
                'args' => array(
                    'year' => array(
                        'required'  => true,
                    ),
                    'month' => array(
                        'required' => true,
                    ),
                ),
                'callback' => function( $data) {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root .'/calendar/year/'.$data->get_param( 'year' ).'/month/'.$data->get_param( 'month' );
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_post($apiUrl, array(
                        'sslverify' => FALSE,

                        'headers'     => array(
                            'Content-Type' => 'application/json; charset=utf-8',
                            'Authorization' => 'Bearer ' .$token['accessToken'],
                        ),
                        'body' => json_encode($data->get_params()),
                        'data_format' => 'body',
                    ));
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return 'fail';
                    }
                }
            ));
            // http://pb.multisite/t1/wp-json/publiticket/v1/events/filters
            register_rest_route('publiticket/v1', '/events/filters', array(
                'methods'  => 'GET',
                'callback' => function() {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root. '/events/filters';
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_get(
                        $apiUrl,
                        array(
                            'sslverify' => FALSE,
                            'headers'     => array(
                                'Authorization' => 'Bearer ' .$token['accessToken'],
                            ),
                        )
                    );
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return $root;
                    }
                }
            ));
            // http://pb.multisite/t1/wp-json/publiticket/v1/events?pageSize=8&page=1
            register_rest_route('publiticket/v1','events', array(
                'methods'  => 'GET',
                'args' => array(
                    'pageSize' => array(
                        'required'  => true,
                    ),
                    'page' => array(
                        'required' => true,
                    ),
                    'year' => array(
                        'required' => false,
                    ),
                    'month' => array(
                        'required' => false,
                    ),
                    'province' => array(
                        'required' => false,
                    ),
                    'location' => array(
                        'required' => false,
                    ),
                    'category' => array(
                        'required' => false,
                    ),
                ),
                'callback' => function( $data ) {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root .'/events?pageSize='.$data->get_param( 'pageSize' )
                        .'&page='.$data->get_param( 'page' )
                        .'&year='.$data->get_param( 'year' )
                        .'&month='.$data->get_param( 'month' )
                        .'&province='.$data->get_param( 'province' )
                        .'&location='.$data->get_param( 'location' )
                        .'&category='.$data->get_param( 'category' )
                    ;
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_get(
                        $apiUrl,
                        array(
                            'sslverify' => FALSE,
                            'headers'     => array(
                                'Authorization' => 'Bearer ' .$token['accessToken'],
                            ),
                        )
                    );
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        header('pagination: '. wp_remote_retrieve_header($response, 'pagination'));
                        header('Access-Control-Expose-Headers: pagination,errors-paginate-filter');
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return null;
                    }
                }
            ));
            // http://pb.multisite/t1/wp-json/publiticket/v1/events/filters/category
            register_rest_route('publiticket/v1', '/events/filters/category', array(
                'methods'  => 'GET',
                'callback' => function() {
                    $root = esc_attr(get_option( 'api_host', '' ) );
                    $apiUrl = $root. '/events/filters/category';
                    $token = WPPubliticket_Api::instance()->call_token();
                    $response = wp_remote_get(
                        $apiUrl,
                        array(
                            'sslverify' => FALSE,
                            'headers'     => array(
                                'Authorization' => 'Bearer ' .$token['accessToken'],
                            ),
                        )
                    );
                    if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                        return  json_decode( wp_remote_retrieve_body( $response ),true );
                    } else {
                        error_log(date("Y-m-d H:i:s") . " - " .$apiUrl . " - " . $response->get_error_message(). "\n", 3 , 'pt_404_errors.log');
                        return 'fail';
                    }
                }
            ));
			// http://pb.multisite/t1/wp-json/publiticket/v1/reload
		    register_rest_route('publiticket/v1', '/reload', array(
			    'methods'  => 'GET',
			    'callback' => array($this,'callback_reload')
		    ));

	    });
    }

	public function callback_reload(): WP_REST_Response {
		try {
			// ----------------------
			// ----------------------
			// ----------------------
			$response = array();
			$result = $this->call_api_seo();
			// ----------------------
			// ----------------------
			// ----------------------
			global $wpdb;
			$prefix = $wpdb->prefix;
			foreach ($result as $v){
				$post_name = $v['slug'];
				$post_title = $v['title'];
				$post_image = $v['image'];
				// ----------------------------------
				$query = "SELECT ID, post_name FROM {$prefix}posts WHERE post_name = '" . $post_name . "'";
				if(! $p = $wpdb->get_row( $query )) {
					$data = array(
						'post_type' => 'ticket',
						'post_title'   => $post_title,
						'post_status'  => 'publish',
						'comment_status' => 'closed',
						'ping_status' => 'closed',
						'post_name' => $post_name,
						'meta_input' => array(
							'_yoast_wpseo_title' => $v['title'],
							'_yoast_wpseo_metadesc' => $v['metadesc'],
							'_yoast_wpseo_metakeywords' => $v['metakeywords'],
							'_yoast_wpseo_focuskw' => $v['focuskw']
						)
					);

					$post_id = wp_insert_post($data, true);
					$response[] = $post_id;
					if (is_wp_error($post_id)) {
						$response[] = "Error: " . $post_id->get_error_message();
					}
					else {
						$image = media_sideload_image( $post_image, $post_id, $post_title,'id' );
						set_post_thumbnail( $post_id, $image );
						do_action( 'wp_insert_post', $post_id, get_post( $post_id ), true );
					}
				}
				else {
					$updated_post = array(
						'ID'           => $p->ID,
						'post_title'   => $post_title,
					);

					$updated_post_id = wp_update_post($updated_post);
					if (is_wp_error($updated_post_id)) {
						$response[] = "Error: " . $updated_post_id->get_error_message();
					}
				}
			}
			$filter = array_map(fn($a): string => $a['slug'], $result);
			$query = "SELECT ID, post_name FROM {$prefix}posts WHERE post_type = 'ticket' AND post_name NOT IN ( '" . implode( "', '" , $filter ) . "' )";
			$list_trash = $wpdb->get_results($query);
			if (!is_wp_error($p)) {
				foreach ($list_trash as $v) {
					$trash_post_id = wp_trash_post($v->ID);
					if (is_wp_error($trash_post_id)) {
						$response[] = "Error: " . $post_id->get_error_message();
					}
				}
			}
			$data =  empty($response) ? $result : $response;
			$status = empty($response) ? 200 : 500;
			// -------------------------------
			return new WP_REST_Response( $data , $status);
		}
		catch (ServerException $e) {
			return new WP_REST_Response( [$e->getMessage()], 500);
		}
	}

	/**
	 * @throws ServerException
	 */
	private function call_api_seo($page = 1, $pageSize = 10 ) : array {
		$root = esc_attr(get_option( 'api_host', '' ) );
		$apiUrl = $root. '/seo?Page='.$page.'&PageSize='.$pageSize;
		$token = WPPubliticket_Api::instance()->call_token();
		$response = wp_remote_get(
			$apiUrl,
			array(
				'sslverify' => FALSE,
				'headers'     => array(
					'Authorization' => 'Bearer ' .$token['accessToken'],
				),
			)
		);
		if ( is_array( $response ) && ! is_wp_error( $response ) ) {
			$pag = json_decode(wp_remote_retrieve_header( $response, 'Pagination' ), true);
			$currentPage = $pag['currentPage'];
			$totalPages = $pag['totalPages'];
			$result = array();
			$body = json_decode( wp_remote_retrieve_body( $response ),true );
			$tags = array(
				'slug' => 'pkIdSlug',
				'title' => 'title',
				'image' => 'urlImageCover',
				'metadesc' => 'seoDescription',
				'metakeywords' => 'seoTags',
				'focuskw' => 'seoFocus',
			);
			foreach($body as $r) {
				$res = array();
				foreach ($tags as $k => $v) {
					if(!array_key_exists($v, $r)) throw new ServerException('Exception mapping' , 500);
					$res[$k] = $r[$v] ?? '';
				}
				$res['data'] = $r;
				$result[] = $res;
			}
			if($currentPage >= $totalPages) {
				return $result;
			}
			return array_merge($result, $this->call_api_seo($currentPage + 1 , $pageSize));
		}
		return array();
	}

    // se incluyen archivos core
    private function includes(): void
    {
	    include_once PT_PLUGIN_PATH . 'includes/pt-core-functions.php'; // funciones core
	    include_once PT_PLUGIN_PATH . 'includes/pt-components-core-functions.php'; // funciones display vue components
	    require_once(ABSPATH . 'wp-admin/includes/media.php');
	    require_once(ABSPATH . 'wp-admin/includes/file.php');
	    require_once(ABSPATH . 'wp-admin/includes/image.php');
    }
    // registro de custom post
    public function add_custom_type_post(): void
    {
        // var_dump('add_custom_type_post');
        $supports = array(
            'title', // post title
            'editor', // post content
            'thumbnail', // featured images
            // 'excerpt', // post excerpt
            // 'custom-fields', // custom fields
            // 'post-formats', // post formats
            );
      
        register_post_type( 'ticket',
        // CPT Options
            array(
                'supports' => $supports,
                'labels' => array(
                    'name' => __( 'Tickets' ),
                    'singular_name' => __( 'Ticket' )
                ),
                'public' => true,
                'has_archive' => true,
                'rewrite' => array('slug' => 'ticket'),
                'show_in_rest' => true,
                'hierarchical' => true,
                'publicly_queryable'  => true,
                // 'capability_type'     => 'post',
      
            )
        );
        // global $wp_rewrite;
        // $wp_rewrite->pagination_base = 'p';

        load_plugin_textdomain( 'publitickets', false, 'publitickets/languages' );
    }

    // activacion de plugin
    public function plugin_prefix_activate(): void
    {
        $this->add_custom_type_post();
        flush_rewrite_rules(); 
    }
    // desactivacion de plugin
    public function remove_custom_type_post(): void
    {
        unregister_post_type( 'ticket' );
        flush_rewrite_rules();
    }
    // manejo de slug evento
     public function modify_pre_handle_404_defaults($preempt, $wp_query) {
        global $wp;
        global $wp_query;
        // ---------------------------
        if(is_admin() || is_favicon()) {
            return $preempt;
        }
        // ---------------------------
        if(is_home() || is_front_page()) {
            $this->ticket->set_event_slug(null);
            $page_id = intval(get_option( 'page_on_front' ));
            if($page_id > 0) {
                $args = array(
                    'p'         => $page_id,
                    'post_type' => array('post', 'page', 'e-landing-page'),
                );
                $GLOBALS['wp_query']  = new WP_Query($args);
                return true;
            }
        }
        else {
            $slug =  $wp_query->get( 'name' );
            $this->ticket->set_event_slug($slug);
            if($slug) {
				// todo validar si el slug existe y si le pertence al sitio que lo manda llamar
	            $page_id = url_to_postid($wp->request);
	            if($page_id == 0) {
		            $GLOBALS['wp_query']  = new WP_Query();
	            }
	            return true;
            }
        }
        return $preempt;
    }
    // carga de templates
    public function template_loader( string  $template ): string
    {
        global $wp;
        $url = explode('/', $wp->request);
        if($url[0] == 'ticket') {
            return pt_get_template_file('publitickets' , $template);
        }
        return $template;
    }

	// actualiza la imagen detacada


}


