<?php
function cp_search_events(): string {
	wp_enqueue_script( 'pt_components' );
	wp_enqueue_style( 'pt_components_css' );
    $nonce = wp_create_nonce( 'wp_rest' );
    $host  = get_site_url(). '/wp-json/publiticket/v1';
    $event = get_site_url() . '/ticket';
    $base = esc_attr(get_option( 'api_base', '' ) );
	ob_start(); ?>
	<div class="pt-component"
	     data-host="<?=$host?>"
	     data-nonce="<?=$nonce?>"
	     data-event="<?=$event?>"
         data-base="<?=$base?>"
	     data-type="search"
	></div>
	<?php
	$output_string = ob_get_contents();
	ob_end_clean();

	return $output_string;
}

function cp_list_events(): string {
	wp_enqueue_script( 'pt_components' );
	wp_enqueue_style( 'pt_components_css' );
	$nonce = wp_create_nonce( 'wp_rest' );
    $host  = get_site_url(). '/wp-json/publiticket/v1';
	$event = get_site_url() . '/ticket';
    $base = esc_attr(get_option( 'api_base', '' ) );
	ob_start(); ?>
    <div class="pt-component"
         data-host="<?=$host?>"
         data-nonce="<?=$nonce?>"
         data-event="<?=$event?>"
         data-base="<?=$base?>"
         data-type="mosaic"
    ></div>

	<?php
	$output_string = ob_get_contents();
	ob_end_clean();

	return $output_string;
}

function cp_events_details(): string {
	wp_enqueue_script( 'pt_components' );
	wp_enqueue_style( 'pt_components_css' );
    $nonce = wp_create_nonce( 'wp_rest' );
    $host  = get_site_url(). '/wp-json/publiticket/v1';
    $event = get_site_url() . '/ticket';
    $base = esc_attr(get_option( 'api_base', '' ) );
	global $pb_ticket;
	$slug  = $pb_ticket->get_event_slug();
	ob_start(); ?>
    <div class="pt-component"
         data-id="<?=$slug?>"
         data-host="<?=$host?>"
         data-nonce="<?=$nonce?>"
         data-event="<?=$event?>"
         data-base="<?=$base?>"
         data-type="calendar"
    ></div>
	<?php
	$output_string = ob_get_contents();
	ob_end_clean();

	return $output_string;
}

function cp_events_carousel(): string {
    wp_enqueue_script( 'pt_components' );
    wp_enqueue_style( 'pt_components_css' );
    $nonce = wp_create_nonce( 'wp_rest' );
    $host  = get_site_url(). '/wp-json/publiticket/v1';
    $event = get_site_url() . '/ticket';
    $base = esc_attr(get_option( 'api_base', '' ) );
    global $pb_ticket;
    $slug  = $pb_ticket->get_event_slug();
    ob_start(); ?>
    <div class="pt-component"
         data-id="<?=$slug?>"
         data-host="<?=$host?>"
         data-nonce="<?=$nonce?>"
         data-event="<?=$event?>"
         data-base="<?=$base?>"
         data-type="carousel"
    ></div>
    <?php
    $output_string = ob_get_contents();
    ob_end_clean();

    return $output_string;
}

function cp_events_categoy(): string {
    wp_enqueue_script( 'pt_components' );
    wp_enqueue_style( 'pt_components_css' );
    $nonce = wp_create_nonce( 'wp_rest' );
    $host  = get_site_url(). '/wp-json/publiticket/v1';
    $event = get_site_url() . '/ticket';
    $base = esc_attr(get_option( 'api_base', '' ) );
    global $pb_ticket;
    ob_start(); ?>
    <div class="pt-component"
         data-host="<?=$host?>"
         data-nonce="<?=$nonce?>"
         data-event="<?=$event?>"
         data-base="<?=$base?>"
         data-type="category"
    ></div>
    <?php
    $output_string = ob_get_contents();
    ob_end_clean();

    return $output_string;
}
