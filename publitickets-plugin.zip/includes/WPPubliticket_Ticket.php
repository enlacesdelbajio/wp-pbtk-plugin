<?php
defined( 'ABSPATH' ) || exit;

final class WPPubliticket_Ticket {
    private static ?WPPubliticket_Ticket $_instance = null;
    /**
     * @var true
     */
    private bool $is_slug = false;

    public static function instance(): ?WPPubliticket_Ticket
    {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    // ---------------------------------------
    // ---------------------------------------
    // ---------------------------------------
    private string|null $event_slug = null;
    public function set_event_slug(string|null $slug): void
    {
        $this->is_slug = ($slug != null);
        $this->event_slug = $slug;
    }
    public function get_event_slug(): ?string
    {
        return $this->event_slug;
    }
    public function isSlug(): bool
    {
        return $this->is_slug;
    }
}
