<div class="pt-error">
    <?=__('Service not available, try again later', 'publitickets');?>
</div>