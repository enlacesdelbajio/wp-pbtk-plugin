<?php
/**
 * The template for displaying all TICKETS posts.
 *
 * @package publitickets
 */
global $pb_ticket;
get_header(); ?>
    <div id="pt-primary">
        <main class="<?=apply_filters( 'pt_class_main', 'site-main' )?>" role="main">
            <?php if($pb_ticket->isSlug()): ?>
                <div class="<?=apply_filters( 'pt_class_content', 'content' )?>">
                <?php
                    echo do_shortcode( '[publiticket_events_details]' );
                    load_template(pt_get_template_file('single'));
                    ?>
                </div>
            <?php endif;?>
            <?php if(!$pb_ticket->isSlug()): ?>
                <div class="<?=apply_filters( 'pt_class_content', 'content-full' )?>">
                    <?php echo do_shortcode( '[publiticket_events]' );?>
                </div>
            <?php endif;?>
        </main>
    </div>


<?php
//
get_footer();
