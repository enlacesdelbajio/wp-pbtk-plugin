<div class="pt-not-found">
    <?=__('Event not found', 'publitickets');?>
</div>